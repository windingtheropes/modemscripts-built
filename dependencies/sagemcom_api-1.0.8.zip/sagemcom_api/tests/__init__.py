"""Test for Sagemcom F@st client."""
