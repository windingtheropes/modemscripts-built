"""Package to communicate with Sagemcom F@st internal APIs."""
__version__ = "1.0.1"
